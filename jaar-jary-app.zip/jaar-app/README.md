# جاري — JARY 🏘️
**Smart Neighborhood Network | شبكة الجيرة الذكية**

## Languages | اللغات
- 🇲🇦 العربية (Arabic)
- 🇫🇷 Français (French)  
- 🇬🇧 English

## AdMob IDs
| Type | ID |
|---|---|
| App ID | ca-app-pub-5606142224218961~5473179910 |
| Interstitial | ca-app-pub-5606142224218961/5473179910 |
| Banner | ca-app-pub-5606142224218961/6720215347 |
| Rewarded | ca-app-pub-5606142224218961/5606865681 |
| Native 1 | ca-app-pub-5606142224218961/5259381325 |
| Native 2 | ca-app-pub-5606142224218961/7614081926 |

## Build APK via GitHub Actions
1. Push to `main` branch
2. Go to **Actions** tab
3. Wait ~5 minutes
4. Download APK from **Artifacts**

## Firebase
- Project: `jaar-web`
- Auth: Phone number
- Database: Firestore
